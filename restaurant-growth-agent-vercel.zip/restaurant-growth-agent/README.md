# Restaurant Growth Agent

This project is ready to deploy on Vercel with a server-side DeepSeek proxy.

## Files
- `index.html`: frontend UI
- `api/chat.js`: Vercel Function that calls DeepSeek
- `vercel.json`: basic Vercel config

## Environment variable
Set this in Vercel:
- `DEEPSEEK_API_KEY` = your DeepSeek API key

## Local test
If you want to test locally with Vercel CLI:

```bash
npm i -g vercel
vercel dev
```

Then open:
- http://localhost:3000

## Deploy
1. Push this folder to GitHub.
2. Import the repo into Vercel.
3. Add `DEEPSEEK_API_KEY` in Project Settings → Environment Variables.
4. Redeploy.
